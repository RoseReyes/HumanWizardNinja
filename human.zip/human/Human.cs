using System;

namespace human {

    public class Human
    {
        public string name;
        public int health { get; set; }
        public int strength { get; set; }
        public int intelligence { get; set; }
        public int dexterity { get; set; }
    
    
        public Human(string firstname) 
        {
            name = firstname;
            strength = 3;
            intelligence = 3;
            dexterity = 3;
            health = 100;
        }
    
        public Human(string secondperson, int newstr, int newintel, int newdex, int newhp)
        {
            name = secondperson;
            strength = newstr;
            intelligence = newintel;
            dexterity = newdex;
            health = newhp;
        }

         public void attack(object target)
        {
            Human enemy = target as Human;
            if(enemy == null)
            {
                Console.WriteLine("Failed Attack");
            }
            else
            {
                enemy.health -= strength * 5;
            }
        }
    
    
    }
}