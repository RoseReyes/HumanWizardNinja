﻿using System;

namespace human
{
    public class Program
    {
        public static void Main(string[] args)
        {
             Human Dave = new Human("Dave");
             Console.WriteLine(Dave.name);
             Human John = new Human("John", 5, 7, 5, 120);
           Console.WriteLine("Character Name: " + Dave.name + " Health: " + Dave.health + " Intelligence: " + Dave.intelligence + " Dexterity: " + Dave.dexterity + " Strength: " + Dave.strength);
           Console.WriteLine("Character Name: " + John.name + " Health: " + John.health + " Intelligence: " + John.intelligence + " Dexterity: " + John.dexterity + " Strength: " + John.strength);
           Console.WriteLine(Dave.name + " is attacking " + John.name);
           Dave.attack(John);
           Console.WriteLine("Character Name: " + Dave.name + " Health: " + Dave.health + " Intelligence: " + Dave.intelligence + " Dexterity: " + Dave.dexterity + " Strength: " + Dave.strength);
           Console.WriteLine("Character Name: " + John.name + " Health: " + John.health + " Intelligence: " + John.intelligence + " Dexterity: " + John.dexterity + " Strength: " + John.strength);
        }
    }
}

